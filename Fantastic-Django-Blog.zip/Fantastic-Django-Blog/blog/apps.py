# -*- coding: utf-8 -*-
from django.apps import AppConfig


class BlogConfig(AppConfig):
    name = "blog"
