# -*- coding: utf-8 -*-
from django.contrib import admin

from accounts.models import Author

# Register your models here.
admin.site.register(Author)
